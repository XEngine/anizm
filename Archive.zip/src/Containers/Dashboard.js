import React from 'react'
import {Link} from 'react-router-dom'

class Dashboard extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>

            </div>
        )
    }

    componentDidMount() {

    }
}

export default Dashboard
