import React from 'react'
import uniqueId from 'lodash/uniqueId'
import classNames from 'classnames'

const id = uniqueId('login-');
export default class FormGroup extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            value: '',
            error: false,
            empty: false
        }
        this.onChangeCallback = this.onChangeCallback.bind(this)
        this.onBlurCallback = this.onBlurCallback.bind(this)
    }

    render() {
        return (
            <div className={classNames('form-group',{'has-warning':this.state.empty})}>
                <label htmlFor={id}>{this.props.label || ''}</label>
                <input
                    type={this.props.type || 'text'}
                    value={this.state.value}
                    onChange={this.onChangeCallback}
                    onBlur={this.onBlurCallback}
                    id={id}
                    name={this.props.name}
                    className={classNames('form-control',{'form-control-warning':this.state.empty})}/>
            </div>
        )
    }

    onChangeCallback(event) {
        this.setState({
            value: event.target.value,
            empty: false
        })

        this.props.callback(event)
    }

    onBlurCallback(event) {
        if (event.target.value.length <= 0) {
            this.setState({
                empty: true
            })
        }
    }
}