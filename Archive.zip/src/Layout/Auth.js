import React from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {login} from '../Actions/LoginActions'

import Login from './Login'
class Auth extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            visible: false
        }
    }


    render() {
        return (
            <div className="header-auth">
                <Login login={this.props.login}/>
                <span> ya da </span>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {auth: state.auth}
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({login: login}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(Auth)