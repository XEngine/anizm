import React from 'react'

const Logo = () => (
    <div className="logo">
        <img src="http://cdn.anizm.tv/img/logo.png"/>
    </div>
)
export default Logo