import React from 'react'
import {connect} from 'react-redux'

import Header from './Header'

class Layout extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div className="wrapper">
                <Header />
                {this.props.children}
            </div>
        )
    }

}

function mapStateToProps(state) {
    return {auth: state.login.data}
}

export default connect(mapStateToProps)(Layout)