import React from 'react'

export default class Search extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div className="header-search">
                <input placeholder="Ara burada bebeğim" className="search-text-box" type="text"/>
            </div>
        )
    }
}