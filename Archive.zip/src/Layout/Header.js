import React from 'react'
import ListItems from './ListItems'
import Search from './Search'
import Auth from './Auth'
import Logo from './Logo'

export default class Header extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div className="header-section-wrapper">
                <div className="header-section container">
                    <Logo/>
                    <ListItems/>
                    <Search/>
                    <Auth/>
                </div>
            </div>
        )
    }
}