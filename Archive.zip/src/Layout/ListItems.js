import React from 'react'
import {Link} from 'react-router-dom'

export default class ListItems extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        return(
            <div className="header-menu">
                <ul className="list-inline">
                    <li className="list-inline-item"><Link to={''} >Anime</Link></li>
                    <li className="list-inline-item"><Link to={''} >Çizgi Film</Link></li>
                    <li className="list-inline-item"><Link to={''} >Tavsiye Robotu</Link></li>
                    <li className="list-inline-item"><Link to={''} >Topluluk</Link></li>
                    <li className="list-inline-item"><Link to={''} >Bize Katılın</Link></li>
                </ul>
            </div>
        )
    }
}