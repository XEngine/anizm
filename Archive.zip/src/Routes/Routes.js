import React from 'react'
import {Route, Switch, Redirect} from 'react-router-dom'
import store from '../store'
import {loginUserSuccess} from '../Actions/LoginActions';
import axios from 'axios'
import CSSTransitionGroup from 'react-transition-group/CSSTransitionGroup'
import Layout from '../Layout/Layout'

import Dashboard from '../Containers/Dashboard'

axios.defaults.baseURL = '/api/api/'
axios.defaults.headers = {
    "Accept" : 'application/json',
    "Content-Type": 'application/json'
}

function loggedIn(nextState, replace) {
    if (!store.getState().login.isLoggedIn) {
        return false
    }
    return true
}

const token = localStorage.getItem('token')
const user = localStorage.getItem('user')
if (token && user) {
    store.dispatch(loginUserSuccess({tokenInformation: token, userInformation: JSON.parse(user)}))
}

const Routes = () => {
    return (
        <div>
            <Route render={({location}) => (
                <Layout>
                    <CSSTransitionGroup
                        component="div"
                        transitionName="example"
                        transitionEnterTimeout={500}
                        transitionLeaveTimeout={300}
                        transitionAppear={true}
                        style={{}}
                        transitionAppearTimeout={500}
                    >
                        <Switch location={location} key={location.key}>
                            <Route exact path="/" component={Dashboard}/>
                        </Switch>
                    </CSSTransitionGroup>
                </Layout>
            )}/>
        </div>
    )
}

export default Routes