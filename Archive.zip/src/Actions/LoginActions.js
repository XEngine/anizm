import * as constants from '../constants'
import axios from 'axios'

export function loginUserRequest() {
    return {
        type: constants.USER_LOGGING_IN
    }
}

export function loginUserSuccess(data) {
    localStorage.setItem('token', data.tokenInformation)
    localStorage.setItem('user', JSON.stringify(data.userInformation))
    axios.defaults.headers = {
        Authorization: 'Token ' + data.tokenInformation
    }
    return {
        type: constants.USER_LOGGED_IN,
        payload: {
            token: data.tokenInformation,
            user: data.userInformation,
        }
    }
}

export function loginUserFailure(error) {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    return {
        type: constants.USER_FAILED_TO_LOGIN
    }
}

export function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    return {
        type: constants.USER_LOGGED_OUT
    }
}

export const login = data => dispatch => {
    dispatch(loginUserRequest())
    return new Promise((resolve, reject) => {
        axios('token', {
            method: 'post',
            data: {
                identification: data.username,
                password: data.password
            }
        }).then(response => {
            try {
                axios('users/' + response.data.userId, {
                    method: 'get',
                }).then(userInfo => {
                    const hash = {username: data.username, password: data.password}
                    const userInformation = Object.assign({}, userInfo.data, {secret: hash})
                    dispatch(loginUserSuccess({
                        tokenInformation: response.data.token,
                        userInformation: userInformation,
                    }));
                    resolve()
                })
            } catch (e) {
                dispatch(loginUserFailure());
                reject()
            }
        }).catch(error => {
            dispatch(loginUserFailure(error));
            reject()
        })
    })
}