import {applyMiddleware, createStore} from 'redux'
import {routerMiddleware, connectRouter} from 'connected-react-router'
import thunk from 'redux-thunk';
import rootReducer from './Reducers/Reducers'
import history from './history'

const store = createStore(
    connectRouter(history)(rootReducer),
    applyMiddleware(
        routerMiddleware(history),
        thunk
    )
)

export default store