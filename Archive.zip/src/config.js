const config = {
    api_url: 'http://titangn.com/community/api/',
}

export default config